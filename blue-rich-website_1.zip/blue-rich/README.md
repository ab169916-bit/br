# Blue Rich website

Static site (no build step). Files: `index.html`, `img/`, `.nojekyll`.

## Deploy on GitHub Pages
1. Create a repository and upload all files, keeping `img/` beside `index.html`.
2. Settings -> Pages -> Deploy from a branch -> `main` / `(root)` -> Save.
3. Live at `https://<username>.github.io/<repo>/` after about a minute.

## Edit
Menu items, prices and contact links are plain HTML in `index.html`.
